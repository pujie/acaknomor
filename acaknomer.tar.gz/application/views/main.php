<a href="/main/gethiburan">Pemenang Hiburan</a>
<a href="/main/getutama">Pemenang Utama</a>